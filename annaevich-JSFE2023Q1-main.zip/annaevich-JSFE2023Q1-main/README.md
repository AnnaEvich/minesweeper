# Task "shelter"
Main page: https://rolling-scopes-school.github.io/annaevich-JSFE2023Q1/shelter/main.html

Pets page: https://rolling-scopes-school.github.io/annaevich-JSFE2023Q1/shelter/pets.html

# Task "minesweeper"
Game page: https://rolling-scopes-school.github.io/annaevich-JSFE2023Q1/minesweeper/index.html
