const itemsStatus = {
  hide: 'hide',
  bomb: 'bomb',
  number: 'number',
  marked: 'marked',
};

let time;
let sec = 0;
let min = 0;

let clickCounter = 0;
let boardSize = 0;
let numberOfBomb = 0;

let soundFlag = true;
let tilesOpenedSound = new Audio('/annaevich-JSFE2023Q1/minesweeper/sound/open.wav');
let flagSound = new Audio('/annaevich-JSFE2023Q1/minesweeper/sound/flag.wav');
let winSound = new Audio('/annaevich-JSFE2023Q1/minesweeper/sound/win.wav');
let loseSound = new Audio('/annaevich-JSFE2023Q1/minesweeper/sound/lose.wav');
let difficulty = 'easy';

/* HTML creators start */
function createContent() {
  let themeSwitcher = createThemeSwitcher();
  let difficultySwitcher = createDifficultySwitcher();
  let soundSwitcher = createSoundSwitcher();
  let statistics = createStatistics();
  let headerHeading = createHeader();
  let container = createMainContainer();
  let bombField = createBombfield();
  let restart = createRestartBlock();
  let history = createHistory();

  headerHeading.appendChild(difficultySwitcher);
  headerHeading.appendChild(statistics);
  container.appendChild(history);
  container.appendChild(restart);
  container.appendChild(bombField);
  container.appendChild(soundSwitcher);

  document.body.appendChild(themeSwitcher);
  document.body.appendChild(headerHeading);
  document.body.appendChild(container);
}

function createThemeSwitcher() {
  let theme = document.createElement('div');
  theme.id = 'theme-switcher';
  theme.dataset.theme = 'day';
  theme.innerText = 'Theme';
  return theme;
}

function createHeader() {
  let header = document.createElement('header');
  header.id = 'header';

  let heading = document.createElement('h1');
  heading.id = 'heading';
  heading.innerText = 'Minesweeper';

  header.appendChild(heading);

  return header;
}

function createDifficultySwitcher() {
  let blockForLevels = document.createElement('div');
  blockForLevels.id = 'change-difficulty-wrapper';

  let levelEasy = document.createElement('div');
  levelEasy.classList.add('level');
  levelEasy.innerText = 'Easy';
  levelEasy.dataset.difficulty = 'easy';
  blockForLevels.appendChild(levelEasy);

  let levelMedium = document.createElement('div');
  levelMedium.classList.add('level');
  levelMedium.innerText = 'Medium';
  levelMedium.dataset.difficulty = 'medium';
  blockForLevels.appendChild(levelMedium);

  let levelHard = document.createElement('div');
  levelHard.classList.add('level');
  levelHard.innerText = 'Hard';
  levelHard.dataset.difficulty = 'hard';
  blockForLevels.appendChild(levelHard);

  return blockForLevels;
}

function createStatistics() {
  let statisticsBlock = document.createElement('div');
  statisticsBlock.classList.add('statistics');

  statisticsBlock.appendChild(createClickCounter());
  statisticsBlock.appendChild(createBombCounter());
  statisticsBlock.appendChild(createTimer());

  return statisticsBlock;
}

function createClickCounter() {
  let clickCounter = document.createElement('div');
  clickCounter.classList.add('click-counter-wrapper');
  clickCounter.innerText = 'Clicks: ';

  let clickNumber = document.createElement('span');
  clickNumber.id = 'click-counter';
  clickNumber.innerText = '0';

  clickCounter.appendChild(clickNumber);

  return clickCounter;
}

function createBombCounter() {
  let bombCounter = document.createElement('div');
  bombCounter.classList.add('bomb-counter-wrapper');
  bombCounter.innerText = 'Mines: ';

  let bombNumber = document.createElement('span');
  bombNumber.id = 'bomb-counter';
  bombNumber.innerText = numberOfBomb;

  bombCounter.appendChild(bombNumber);

  return bombCounter;
}

function createTimer() {
  let timer = document.createElement('div');

  timer.id = 'timer';
  timer.innerText = '00:00';

  return timer;
}

function createMainContainer() {
  let mainContainer = document.createElement('main');

  mainContainer.id = 'main-container';

  return mainContainer;
}

function createSoundSwitcher() {
  let soundHandler = document.createElement('div');

  soundHandler.id = 'sound-switcher';
  soundHandler.dataset.value = 'on';
  soundHandler.innerText = 'Sound ON';

  return soundHandler;
}

function createBombfield() {
  let bombfield = document.createElement('div');

  bombfield.id = 'bombfield';

  return bombfield;
}

function createRestartBlock() {
  let restartBlock = document.createElement('div');
  restartBlock.id = 'restart-block';

  let restartImg = document.createElement('img');
  restartImg.src = '/annaevich-JSFE2023Q1/minesweeper/image/restart.png';

  restartBlock.appendChild(restartImg);

  return restartBlock;
}

function createTile() {
  let tile = document.createElement('div');

  tile.dataset.status = itemsStatus.hide;

  return tile;
}

function createHistory() {
  let historyBlockWrapper = document.createElement('div');
  historyBlockWrapper.id = 'history-wrapper';

  let historyButton = document.createElement('div');
  historyButton.id = 'history-button';
  historyButton.innerText = 'Your results';

  let resultBlock = document.createElement('div');
  resultBlock.id = 'last-results';
  resultBlock.style.display = 'none'

  let history = getHistory();
  for (let note of history) {
    resultBlock.appendChild(createHistoryRow(note));
  }

  historyBlockWrapper.appendChild(historyButton);
  historyBlockWrapper.appendChild(resultBlock);

  return historyBlockWrapper;
}

function createHistoryRow(note) {
  let historyRow = document.createElement('div');
  historyRow.classList.add('history-row');

  historyRow.innerText = 'Status: ' + note.status + ' Time: ' + note.timer + ' Clicks: ' + note.clicks;

  return historyRow;
}

/* HTML creators end */

/* Functionality start */
function tick() {
  sec++;
  if (sec >= 60) {
    sec = 0;
    min++;
  }
}

function addTick() {
  tick();

  let timer = document.getElementById('timer');
  timer.innerText = (min > 9 ? min : '0' + min) + ':' + (sec > 9 ? sec : '0' + sec);

  startTimer();
}

function startTimer() {
  time = setTimeout(addTick, 1000);
}

function stopTimer() {
  clearTimeout(time);
}

function restartTimer() {
  stopTimer();
  document.getElementById('timer').innerText = '00:00';
  sec = 0;
  min = 0;
}

function setDifficulty(difficultyValue) {
  let bombfield = document.querySelector('#bombfield');
  let changeMainContainer = document.querySelector('#main-container');

  if (difficultyValue === 'hard') {
    boardSize = 25;
    numberOfBomb = 50;
    difficulty = 'hard';
    bombfield.classList = '';
    bombfield.classList.add('l')
  } else if (difficultyValue === 'medium') {
    boardSize = 15;
    numberOfBomb = 30;
    difficulty = 'medium';
    bombfield.classList = '';
    bombfield.classList.add('m')
  } else {
    boardSize = 10;
    numberOfBomb = 10;
    difficulty = 'easy';
    bombfield.classList = '';
    bombfield.classList.add('s')
  }

  setBombNumber(numberOfBomb);
}

function fillBombfield() {
  let bombfield = document.getElementById('bombfield');

  if (bombfield.childElementCount > 0) {
    bombfield.replaceChildren();
  }

  let tilesData = getTiles();
  tilesData.forEach(row => {
    row.forEach(tile => {
      bombfield.append(tile.html);
      initTileHandler(tile, tilesData);
    });
  });

  bombfield.style.setProperty('--size', boardSize.toString());
}

function getTiles() {
  let field = [];
  let bombPosition = getBombPosition();

  for (let x = 0; x < boardSize; x++) {
    let rows = [];

    for (let y = 0; y < boardSize; y++) {
      let tile = {
        html: createTile(),
        x: x,
        y: y,
        bomb: bombPosition.some(checkForPositionMatch.bind(null, {x, y})),
        get status() {
          return this.html.dataset.status;
        },
        set status(value) {
          this.html.dataset.status = value;
        },
      };
      rows.push(tile);
    }

    field.push(rows);
  }

  return field;
}

function revealTile(tilesData, tile) {
  if (tile.status !== itemsStatus.hide) {
    return;
  }

  if (tile.bomb) {
    tile.status = itemsStatus.bomb;
    stopTimer();
    return;
  }

  tile.status = itemsStatus.number;
  let nearbyTiles = findNearbyTilesAndMark(tilesData, tile);
  let mines = nearbyTiles.filter(t => t.bomb);
  if (mines.length === 0) {
    nearbyTiles.forEach(revealTile.bind(null, tilesData));
  } else {
    tile.html.dataset.value = mines.length.toString();
    tile.html.innerText = mines.length.toString();
  }

  playSound(tilesOpenedSound);
}

function playSound(sound) {
  if (soundFlag) {
    sound.currentTime = 0;
    sound.play();
  }
}

function markTile(tile) {
  if (tile.status !== itemsStatus.hide && tile.status !== itemsStatus.marked) {
    return;
  }

  if (tile.status === itemsStatus.marked) {
    tile.status = itemsStatus.hide;
  } else {
    playSound(flagSound);
    tile.status = itemsStatus.marked;
  }
}

function findNearbyTilesAndMark(field, {x, y}) {
  let tiles = [];
  for (let xOffset = -1; xOffset <= 1; xOffset++) {
    for (let yOffset = -1; yOffset <= 1; yOffset++) {
      let tile = field[x + xOffset]?.[y + yOffset];
      if (tile) {
        tiles.push(tile);
      }
    }
  }
  return tiles;
}

function setBombNumber(number) {
  document.getElementById('bomb-counter').innerText = number.toString();
}

function recountBombNumber(bombfield) {
  let markedTiles = bombfield.reduce((count, row) => {
    return count +
        row.filter(tile => tile.status === itemsStatus.marked).length;
  }, 0);

  setBombNumber(numberOfBomb - markedTiles);
}

function getBombPosition() {
  let positions = [];

  while (positions.length < numberOfBomb) {
    let position = {
      x: getRandomNumber(boardSize),
      y: getRandomNumber(boardSize),
    };
    if (!positions.some(checkForPositionMatch.bind(null, position))) {
      positions.push(position);
    }
  }

  return positions;
}

function showBombPositions(bombfield) {
  bombfield.forEach(function(row) {
    row.forEach(function(tile) {
      if (tile.bomb) {
        revealTile(bombfield, tile);
      }
    });
  });
}

function checkForPositionMatch(a, b) {
  return a.x === b.x && a.y === b.y;
}

function getRandomNumber(size) {
  return Math.floor(Math.random() * size);
}

function restartGame() {
  resetClickCounter();
  resetBombCounter();
  restartTimer();

  setDifficulty(difficulty);
  fillBombfield();

  enableBombfield();
}

function checkGameStatus(bombfield) {
  const win = checkWin(bombfield);
  const lose = checkLose(bombfield);

  if (clickCounter === 0) {
    startTimer();
  }

  if (win || lose) {
    disableBombfield();

    stopTimer();

    if (win) {
      showWinAlert();
    }

    if (lose) {
      showBombPositions(bombfield);
      showLoseAlert();
    }
  }
}

function checkWin(bombfield) {
  return bombfield.every(row => {
    return row.every(tile => {
      return tile.status === itemsStatus.number || (tile.bomb && tile.status === itemsStatus.marked);
    });
  });
}

function checkLose(bombfield) {
  return bombfield.some(row => {
    return row.some(tile => {
      return tile.status === itemsStatus.bomb;
    });
  });
}

function showWinAlert() {
  playSound(winSound);
  let winText = document.querySelector('.bomb-counter-wrapper');
  winText.innerText = 'WIN';
  winText.style.color = 'lime';

  addToHistory(collectHistoryData('WIN'));
}

function showLoseAlert() {
  playSound(loseSound);
  let loseText = document.querySelector('.bomb-counter-wrapper');
  loseText.innerText = 'LOSE';
  loseText.style.color = 'red';

  addToHistory(collectHistoryData('LOSE'));
}

function collectHistoryData(status) {
  return {
    status: status,
    timer: document.getElementById('timer').innerText,
    clicks: document.getElementById('click-counter').innerText,
  };
}

function disableBombfield() {
  document.getElementById('bombfield').style.pointerEvents = 'none';
}

function enableBombfield() {
  document.getElementById('bombfield').style.pointerEvents = 'all';
  document.getElementById('bombfield').removeEventListener('click', disableBombfield, {capture: true});
  document.getElementById('bombfield').removeEventListener('contextmenu', disableBombfield, {capture: true});
}

function resetClickCounter() {
  clickCounter = 0;
  document.getElementById('click-counter').innerText = '0';
}

function resetBombCounter() {
  let bombCounter = document.getElementById('bomb-counter');
  if (bombCounter) {
    bombCounter.innerText = numberOfBomb.toString();
  } else {
    let bombCounterWrapper = document.querySelector('.bomb-counter-wrapper');
    bombCounterWrapper.style.color = '#fdfbfb';
    bombCounterWrapper.innerText = 'Mines: ';

    let bombNumber = document.createElement('span');
    bombNumber.id = 'bomb-counter';
    bombNumber.innerText = numberOfBomb;

    bombCounterWrapper.appendChild(bombNumber);
  }
}

function addToHistory(data) {
  let history = getHistory();

  let historyBlock = document.getElementById('last-results');
  if (history.length >= 10) {
    historyBlock.firstChild.remove();
  }
  historyBlock.appendChild(createHistoryRow(data));

  history.push(data);
  localStorage.setItem('history', JSON.stringify(history));
}

function getHistory() {
  let history = localStorage.getItem('history') ? JSON.parse(localStorage.getItem('history')) : [];

  return history.slice(-10);
}

function clearHistory() {
  localStorage.clear();
}

/* Functionality end */

/* Handlers start */
function initHandlers() {
  initClickHandler();
  initThemeChangeHandler();
  initDifficultyChangeHandler();
  initSoundHandler();
  initRestartHandler();
  initHistoryHandler()
}

function initClickHandler() {
  let bombfield = document.querySelector('#bombfield');
  let clickNumber = document.querySelector('#click-counter');

  bombfield.addEventListener('click', function() {
    clickCounter++;
    clickNumber.innerText = clickCounter;
  });
  bombfield.addEventListener('contextmenu', function() {
    clickCounter++;
    clickNumber.innerText = clickCounter;
  });
}

function initSoundHandler() {
  let soundSwitcher = document.querySelector('#sound-switcher');

  soundSwitcher.addEventListener('click', function() {
    if (soundSwitcher.dataset.value === 'on') {
      soundFlag = false;
      soundSwitcher.dataset.value = 'off';
      soundSwitcher.innerText = 'Sound OFF';

    } else if (soundSwitcher.dataset.value === 'off') {
      soundFlag = true;
      soundSwitcher.dataset.value = 'on';
      soundSwitcher.innerText = 'Sound ON';
    }
  });
}

function initThemeChangeHandler() {
  let themeButton = document.querySelector('#theme-switcher');

  themeButton.addEventListener('click', function() {
    if (themeButton.dataset.theme === 'day') {
      document.body.style.background = 'url("/annaevich-JSFE2023Q1/minesweeper/image/night.webp")';
      themeButton.dataset.theme = 'night';
      themeButton.style.background = 'linear-gradient(210deg, rgb(252, 237, 6) 0%, rgb(250, 246, 246) 10%, rgb(236, 182, 123) 100%)';
      themeButton.style.color = 'black';
    } else {
      document.body.style.background = 'url("/annaevich-JSFE2023Q1/minesweeper/image/day.webp")';
      themeButton.dataset.theme = 'day';
      themeButton.style.background = 'linear-gradient(210deg, rgb(8, 12, 86) 0%, rgb(250, 246, 246) 10%, rgb(51, 58, 101) 100%)';
      themeButton.style.color = '#fdfbfb';
    }
    document.body.style.backgroundSize = 'cover';
  });
}

function initDifficultyChangeHandler() {
  let levelList = document.querySelectorAll('.level');

  levelList.forEach(function(level) {
    level.addEventListener('click', function() {
      setDifficulty(level.dataset.difficulty);
      fillBombfield();
    });
  });
}

function initTileHandler(tile, tilesData) {
  tile.html.addEventListener('click', event => {
    revealTile(tilesData, tile);
    checkGameStatus(tilesData);
  });

  tile.html.addEventListener('contextmenu', event => {
    event.preventDefault();
    markTile(tile);
    recountBombNumber(tilesData);
    checkGameStatus(tilesData);
  });
}

function initRestartHandler() {
  let restartHandler = document.querySelector('#restart-block');
  restartHandler.addEventListener('click', function() {
    restartGame();
  });
}

function initHistoryHandler() {
  let resultButton = document.getElementById('history-button');
  let historyBlock = document.getElementById('last-results');
  let bombfield = document.getElementById('bombfield');

  if (resultButton && historyBlock) {
    resultButton.addEventListener('click', function(event) {
      if (historyBlock.style.display === 'none') {
        historyBlock.style.display = 'grid';
        bombfield.style.display = 'none';
      } else {
        historyBlock.style.display = 'none';
        bombfield.style.display = '';
      }
    });
  }
}

/* Handlers end */

document.addEventListener('DOMContentLoaded', function() {
  createContent();

  setDifficulty(difficulty);
  fillBombfield();

  initHandlers();
});