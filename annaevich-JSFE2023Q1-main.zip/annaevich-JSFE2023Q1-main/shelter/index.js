const petsData = [
    {
        "name": "Jennifer",
        "img": "../upload/pets-jennifer.png",
        "type": "Dog",
        "breed": "Labrador",
        "description": "Jennifer is a sweet 2 months old Labrador that is patiently waiting to find a new forever home. This girl really enjoys being able to go outside to run and play, but won't hesitate to play up a storm in the house if she has all of her favorite toys.",
        "age": "2 months",
        "inoculations": ["none"],
        "diseases": ["none"],
        "parasites": ["none"]
    },
    {
        "name": "Sophia",
        "img": "../upload/pets-katrine.png",
        "type": "Dog",
        "breed": "Shih tzu",
        "description": "Sophia here and I'm looking for my forever home to live out the best years of my life. I am full of energy. Everyday I'm learning new things, like how to walk on a leash, go potty outside, bark and play with toys and I still need some practice.",
        "age": "1 month",
        "inoculations": ["parvovirus"],
        "diseases": ["none"],
        "parasites": ["none"]
    },
    {
        "name": "Woody",
        "img": "../upload/pets-woody.png",
        "type": "Dog",
        "breed": "Golden Retriever",
        "description": "Woody is a handsome 3 1/2 year old boy. Woody does know basic commands and is a smart pup. Since he is on the stronger side, he will learn a lot from your training. Woody will be happier when he finds a new family that can spend a lot of time with him.",
        "age": "3 years 6 months",
        "inoculations": ["adenovirus", "distemper"],
        "diseases": ["right back leg mobility reduced"],
        "parasites": ["none"]
    },
    {
        "name": "Scarlett",
        "img": "../upload/pets-scarlet.png",
        "type": "Dog",
        "breed": "Jack Russell Terrier",
        "description": "Scarlett is a happy, playful girl who will make you laugh and smile. She forms a bond quickly and will make a loyal companion and a wonderful family dog or a good companion for a single individual too since she likes to hang out and be with her human.",
        "age": "3 months",
        "inoculations": ["parainfluenza"],
        "diseases": ["none"],
        "parasites": ["none"]
    },
    {
        "name": "Katrine",
        "img": "../upload/pets-katrinecat.png",
        "type": "Cat",
        "breed": "British Shorthair",
        "description": "Katrine is a beautiful girl. She is as soft as the finest velvet with a thick lush fur. Will love you until the last breath she takes as long as you are the one. She is picky about her affection. She loves cuddles and to stretch into your hands for a deeper relaxations.",
        "age": "6 months",
        "inoculations": ["panleukopenia"],
        "diseases": ["none"],
        "parasites": ["none"]
    },
    {
        "name": "Timmy",
        "img": "../upload/pets-timmy.png",
        "type": "Cat",
        "breed": "British Shorthair",
        "description": "Timmy is an adorable grey british shorthair male. He loves to play and snuggle. He is neutered and up to date on age appropriate vaccinations. He can be chatty and enjoys being held. Timmy has a lot to say and wants a person to share his thoughts with.",
        "age": "2 years 3 months",
        "inoculations": ["calicivirus", "viral rhinotracheitis"],
        "diseases": ["kidney stones"],
        "parasites": ["none"]
    },
    {
        "name": "Freddie",
        "img": "../upload/Freddie.png",
        "type": "Cat",
        "breed": "British Shorthair",
        "description": "Freddie is a little shy at first, but very sweet when he warms up. He likes playing with shoe strings and bottle caps. He is quick to learn the rhythms of his human’s daily life. Freddie has bounced around a lot in his life, and is looking to find his forever home.",
        "age": "2 months",
        "inoculations": ["rabies"],
        "diseases": ["none"],
        "parasites": ["none"]
    },
    {
        "name": "Charly",
        "img": "../upload/charly.png",
        "type": "Dog",
        "breed": "Jack Russell Terrier",
        "description": "This cute boy, Charly, is three years old and he likes adults and kids. He isn’t fond of many other dogs, so he might do best in a single dog home. Charly has lots of energy, and loves to run and play. We think a fenced yard would make him very happy.",
        "age": "8 years",
        "inoculations": ["bordetella bronchiseptica", "leptospirosis"],
        "diseases": ["deafness", "blindness"],
        "parasites": ["lice", "fleas"]
    }
]

function switchScrollMod() {
    if (document.body.classList.contains('scroll-off')) {
        document.body.classList.remove('scroll-off');
    } else {
        document.body.classList.add('scroll-off');
    }
}

function shuffle(array) {
    let i = array.length;

    while (i--) {
        const ri = Math.floor(Math.random() * i);
        [array[i], array[ri]] = [array[ri], array[i]];
    }

    return array;
}

function generatePaginationContent(numOfPages) {
    let result = {};

    for (let i = 1; i <= numOfPages; i++) {
        result[i] = shuffle([
            {
                "name": "Jennifer",
                "img": "../upload/pets-jennifer.png",
                "type": "Dog",
                "breed": "Labrador",
                "description": "Jennifer is a sweet 2 months old Labrador that is patiently waiting to find a new forever home. This girl really enjoys being able to go outside to run and play, but won't hesitate to play up a storm in the house if she has all of her favorite toys.",
                "age": "2 months",
                "inoculations": ["none"],
                "diseases": ["none"],
                "parasites": ["none"]
            },
            {
                "name": "Sophia",
                "img": "../upload/pets-katrine.png",
                "type": "Dog",
                "breed": "Shih tzu",
                "description": "Sophia here and I'm looking for my forever home to live out the best years of my life. I am full of energy. Everyday I'm learning new things, like how to walk on a leash, go potty outside, bark and play with toys and I still need some practice.",
                "age": "1 month",
                "inoculations": ["parvovirus"],
                "diseases": ["none"],
                "parasites": ["none"]
            },
            {
                "name": "Woody",
                "img": "../upload/pets-woody.png",
                "type": "Dog",
                "breed": "Golden Retriever",
                "description": "Woody is a handsome 3 1/2 year old boy. Woody does know basic commands and is a smart pup. Since he is on the stronger side, he will learn a lot from your training. Woody will be happier when he finds a new family that can spend a lot of time with him.",
                "age": "3 years 6 months",
                "inoculations": ["adenovirus", "distemper"],
                "diseases": ["right back leg mobility reduced"],
                "parasites": ["none"]
            },
            {
                "name": "Scarlett",
                "img": "../upload/pets-scarlet.png",
                "type": "Dog",
                "breed": "Jack Russell Terrier",
                "description": "Scarlett is a happy, playful girl who will make you laugh and smile. She forms a bond quickly and will make a loyal companion and a wonderful family dog or a good companion for a single individual too since she likes to hang out and be with her human.",
                "age": "3 months",
                "inoculations": ["parainfluenza"],
                "diseases": ["none"],
                "parasites": ["none"]
            },
            {
                "name": "Katrine",
                "img": "../upload/pets-katrinecat.png",
                "type": "Cat",
                "breed": "British Shorthair",
                "description": "Katrine is a beautiful girl. She is as soft as the finest velvet with a thick lush fur. Will love you until the last breath she takes as long as you are the one. She is picky about her affection. She loves cuddles and to stretch into your hands for a deeper relaxations.",
                "age": "6 months",
                "inoculations": ["panleukopenia"],
                "diseases": ["none"],
                "parasites": ["none"]
            },
            {
                "name": "Timmy",
                "img": "../upload/pets-timmy.png",
                "type": "Cat",
                "breed": "British Shorthair",
                "description": "Timmy is an adorable grey british shorthair male. He loves to play and snuggle. He is neutered and up to date on age appropriate vaccinations. He can be chatty and enjoys being held. Timmy has a lot to say and wants a person to share his thoughts with.",
                "age": "2 years 3 months",
                "inoculations": ["calicivirus", "viral rhinotracheitis"],
                "diseases": ["kidney stones"],
                "parasites": ["none"]
            },
            {
                "name": "Freddie",
                "img": "../upload/Freddie.png",
                "type": "Cat",
                "breed": "British Shorthair",
                "description": "Freddie is a little shy at first, but very sweet when he warms up. He likes playing with shoe strings and bottle caps. He is quick to learn the rhythms of his human’s daily life. Freddie has bounced around a lot in his life, and is looking to find his forever home.",
                "age": "2 months",
                "inoculations": ["rabies"],
                "diseases": ["none"],
                "parasites": ["none"]
            },
            {
                "name": "Charly",
                "img": "../upload/charly.png",
                "type": "Dog",
                "breed": "Jack Russell Terrier",
                "description": "This cute boy, Charly, is three years old and he likes adults and kids. He isn’t fond of many other dogs, so he might do best in a single dog home. Charly has lots of energy, and loves to run and play. We think a fenced yard would make him very happy.",
                "age": "8 years",
                "inoculations": ["bordetella bronchiseptica", "leptospirosis"],
                "diseases": ["deafness", "blindness"],
                "parasites": ["lice", "fleas"]
            }
        ]);
    }

    return result;
}

function generatePetCardListHTML(petObject) {
    let result = "";

    result += "<div class='pets-content-card' id='" + petObject.name.toLowerCase().trim() + "'>";
    result += "<img src='" + petObject.img + "' alt='" + petObject.name + "'>";
    result += "<p>" + petObject.name + "</p>"
    result += "<div class='learn-more'>" + "<a href='#'>" + "Learn more" + "</a>" + "</div>"
    result += "</div>";

    return result
}

document.addEventListener('DOMContentLoaded', function (event) {
    let gap;
    let pageNum;

    function getPetCardListHTML(page) {
        let resultHTML = "";

        if (petsPagesObject[page]) {
            petsPagesObject[page].forEach(function (petCard) {
                resultHTML += generatePetCardListHTML(petCard)
            })
        }

        return resultHTML;
    }

    function setPaginationButtons(selectedPage) {
        let endButton = document.getElementById("next-last-time");
        if (endButton) {
            endButton.setAttribute('data-value', pageNum)
            if (selectedPage == pageNum) {
                endButton.classList.add('disabled')
            } else {
                endButton.classList.remove('disabled')
            }
        }

        let startButton = document.getElementById("prev-first-time");
        if (startButton) {
            startButton.setAttribute('data-value', 1)
            if (selectedPage == 1) {
                startButton.classList.add('disabled')
            } else {
                startButton.classList.remove('disabled')
            }
        }

        let nextButton = document.getElementById("next-one-time");
        if (nextButton) {
            nextButton.setAttribute('data-value', selectedPage + 1)
            if (selectedPage == pageNum) {
                nextButton.classList.add('disabled')
            } else {
                nextButton.classList.remove('disabled')
            }
        }

        let prevButton = document.getElementById("prev-one-time");
        if (prevButton) {
            prevButton.setAttribute('data-value', selectedPage - 1)
            if (selectedPage == 1) {
                prevButton.classList.add('disabled')
            } else {
                prevButton.classList.remove('disabled')
            }
        }

        let currentPage = document.getElementById("current-page");
        if (currentPage) {
            currentPage.setAttribute('data-value', selectedPage)
            currentPage.innerHTML = selectedPage;
        }
    }

    function setPaginationResponse(page) {
        let htmlResponse = getPetCardListHTML(page);
        if (htmlResponse) {
            petsPageCardsContainer.innerHTML = htmlResponse
            setPaginationButtons(page);
        }
    }

    function setSliderGap() {
        if (window.matchMedia("(min-width: 1280px)").matches) {
            gap = 90;
        } else if (window.matchMedia("(min-width: 768px)").matches && window.matchMedia("(max-width: 1279px)").matches) {
            gap = 40;
        } else if (window.matchMedia("(max-width: 767px)").matches) {
            gap = 0
        }
    }

    function setPageNum() {
        if (window.matchMedia("(min-width: 1280px)").matches) {
            pageNum = 6;
        } else if (window.matchMedia("(min-width: 768px)").matches && window.matchMedia("(max-width: 1279px)").matches) {
            pageNum = 8;
        } else if (window.matchMedia("(max-width: 767px)").matches) {
            pageNum = 16
        }
    }

    function closeBurgerMenu() {
        let burgerMenuClassList = document.getElementById('nav-burger').classList;
        if (burgerMenuClassList.contains('active')) {
            burgerMenuClassList.remove('active')
        } else {
            burgerMenuClassList.add('active');
        }
    }

    function rotateBurgerMenuButton() {
        let burgerButtonClassList = document.getElementById('burger').classList;
        if (burgerButtonClassList.contains('active')) {
            burgerButtonClassList.remove('active')
        } else {
            burgerButtonClassList.add('active');
        }
    }

    function burgerMenuClickHandler() {
        switchScrollMod();
        rotateBurgerMenuButton();
        closeBurgerMenu();
    }

    function initSlider() {
        let width;
        const carousel = document.getElementById("carousel");
        const content = document.getElementById("carousel");

        const next = document.getElementById("arrow-right");
        const prev = document.getElementById("arrow-left");

        const prevMobile = document.getElementById('arrow-mobile-left')
        const nextMobile = document.getElementById('arrow-mobile-right')

        if (next) {
            next.addEventListener("click", e => {
                carousel.scrollBy(width + gap, 0);
                if (carousel.scrollLeft + width === content.scrollWidth) {
                    carousel.scroll({
                        left: 0,
                    })
                }
            });
        }
        if (nextMobile) {
            nextMobile.addEventListener("click", e => {
                carousel.scrollBy(width + gap, 0);
                if (carousel.scrollLeft + width === content.scrollWidth) {
                    carousel.scroll({
                        left: 0,
                    })
                }
            });
        }
        if (prev) {
            prev.addEventListener("click", e => {
                carousel.scrollBy(-(width + gap), 0);
                if (carousel.scrollLeft === 0) {
                    carousel.scroll({
                        left: content.scrollWidth,
                    })
                }
            });
        }
        if (prevMobile) {
            prevMobile.addEventListener("click", e => {
                carousel.scrollBy(-(width + gap), 0);
                if (carousel.scrollLeft === 0) {
                    carousel.scroll({
                        left: content.scrollWidth,
                    })
                }
            });
        }
        if (carousel) {
            width = carousel.offsetWidth;
        }

    }

    function getObjByValueName(petName) {
        return petsData.find(item => item.name.toLowerCase().trim() === petName.toLowerCase().trim())
    }

    function popUpPetCardListHTML(petObject) {
        let resultPopUp = "";

        resultPopUp += "<div class='popup-content-close-button' id='popup-close-button'>" +
            "<img src='../upload/Vector.png' class='popup-content-close-button-cross'>" +
            "</div>";
        resultPopUp += "<div class='popup-content-image'>" +
            "<img src='" + petObject.img + "'>" +
            "</div>";
        resultPopUp += "<div class='popup-content-text'>" +
            "<div class='popup-content-text-title'>" +
            petObject.name +
            "</div>";
        resultPopUp += "<div class='popup-content-text-subtitle'>" +
            petObject.type + " – " + petObject.breed +
            "</div>";
        resultPopUp += "<div class='popup-content-text-description'>" +
            petObject.description +
            "</div>";
        resultPopUp += "<div class='popup-content-text-list'>" +
            "<div class='list-item'>" +
            "<b>Age: </b>" + petObject.age +
            "</div>" +
            "<div class='list-item'>" +
            "<b>Inoculations: </b>" + petObject.inoculations +
            "</div>" +
            "<div class='list-item'>" +
            "<b>Diseases: </b>" + petObject.diseases +
            "</div>" +
            "<div class='list-item'>" +
            "<b>Parasites: </b>" + petObject.parasites +
            "</div>" +
            "</div>";
        resultPopUp += "</div>";

        return resultPopUp
    }

    document.addEventListener('click', function (event) {
        let popUp = document.querySelector('.popup')
        if(popUp.classList.contains('active') && !event.target.closest('.pets-content-card') && !event.target.closest('.popup-content')){
            popUp.classList.remove('active')
            switchScrollMod();
        }
    });

    setPageNum()
    setSliderGap();
    initSlider();
    setPaginationButtons(1);

    let petsPagesObject = generatePaginationContent(pageNum);
    let petsPageCardsContainer = document.getElementById('pagination-number');
    if (petsPageCardsContainer) {
        petsPageCardsContainer.innerHTML = getPetCardListHTML(1);
    }

    let nextButton = document.getElementById("next-one-time");
    if (nextButton) {
        nextButton.addEventListener('click', function () {
            let page = parseInt(nextButton.getAttribute('data-value'));
            setPaginationResponse(page)
        });
    }

    let prevButton = document.getElementById("prev-one-time");
    if (prevButton) {
        prevButton.addEventListener('click', function () {
            let page = parseInt(prevButton.getAttribute('data-value'));
            setPaginationResponse(page)
        });
    }

    let firstButton = document.getElementById("prev-first-time");
    if (firstButton) {
        firstButton.addEventListener('click', function () {
            let page = parseInt(firstButton.getAttribute('data-value'));
            setPaginationResponse(page)
        });
    }

    let lastButton = document.getElementById("next-last-time");
    if (lastButton) {
        lastButton.addEventListener('click', function () {
            let page = parseInt(lastButton.getAttribute('data-value'));
            setPaginationResponse(page)
        });
    }


    window.addEventListener("resize", () => {
        setSliderGap();
    });

    document.getElementById('burger').onclick = burgerMenuClickHandler;

    document.querySelectorAll('.link').forEach(link => link.onclick = burgerMenuClickHandler);

    document.querySelectorAll(".pets-content-card").forEach(function (card) {
        card.addEventListener("click", function (event) {
            let petName = event.target.closest('.pets-content-card').id.trim()
            let petObject = getObjByValueName(petName)
            let popupContentBlock = document.getElementById('popup-content');
            popupContentBlock.innerHTML = popUpPetCardListHTML(petObject);
            popupContentBlock.closest('.popup').classList.add('active');
            switchScrollMod();
            document.getElementById('popup-close-button').addEventListener("click", function (){
                document.querySelector('.popup').classList.remove('active')
                switchScrollMod();
            })
        })
    })
})